﻿namespace Paleteria {
    
    
    public partial class DataSet1 {
    }
}
